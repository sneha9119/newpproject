export const DB_NAME = "SkillSwap";
